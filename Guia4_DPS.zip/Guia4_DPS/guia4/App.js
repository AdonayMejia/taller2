
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, SafeAreaView, } from 'react-native';
import react, { useState } from 'react';

import colors from './src/utils/colors';
import Form from './src/components/form';
import Footer from './src/components/Footer';

export default function App() {

  const [capital, setCapital] = useState(null);
  const [interest, setInterest] = useState(null);
  const [months, setMonths] = useState(null);
  return (
    <>
    <StatusBar barStyle="light-content"/>
  <SafeAreaView style={styles.Header}>
    <Text style={styles.HeadApp}>Cotizador de Prestamos</Text>
    <Form
      setCapital={setCapital}
      setInterest={setInterest}
      setMonths={setMonths}/>
  </SafeAreaView>
  <View>
    <Text>Result</Text>
  </View>
  <Footer></Footer>
    
 </>
  );
}

const styles = StyleSheet.create({
  Header: {
    backgroundColor:colors.PRIMARY_COLOR,
    height:250,
    borderBottomLeftRadius:30,
    borderBottomRightRadius:30,
    alignItems:'center'
  },
  HeadApp:{
    fontSize:25,
    fontWeight:'bold',
    color:'#fff',
    marginTop:15,
    zIndex:1
  },
});
